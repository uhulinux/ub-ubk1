#!/bin/bash

./Setup-qt4.sh
