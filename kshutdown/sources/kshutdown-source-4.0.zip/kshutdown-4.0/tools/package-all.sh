#!/bin/bash

./tools/api.sh

./tools/i18n.sh

./tools/package-zip-source.sh
