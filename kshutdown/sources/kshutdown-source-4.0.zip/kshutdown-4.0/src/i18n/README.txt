WARNING: All the *.qm files are generated automatically
         from the po/*.po files.

NOTE: Sync. with kshutdown.qrc file.
