=== About Frescobaldi ===

Frescobaldi is named after
[http://en.wikipedia.org/wiki/Girolamo_Frescobaldi
Girolamo Frescobaldi (1583-1643)],
an Italian organist and composer.

Frescobaldi's homepage is at [http://www.frescobaldi.org/]
and there is a mailinglist at [frescobaldi@googlegroups.com]
([http://groups.google.com/group/frescobaldi more info]).

#SUBDOCS
credits
contributing
history
