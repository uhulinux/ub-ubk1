=== Preferences ===

In the Preferences Dialog (under {menu_edit_preferences}) you can configure 
many aspects of Frescobaldi and LilyPond.

#VARS
menu_edit_preferences menu edit -> Pr&eferences...

#SUBDOCS
prefs_general
prefs_lilypond
prefs_midi
prefs_helpers
prefs_paths
prefs_lilydoc
prefs_shortcuts
prefs_editor
prefs_fontscolors
prefs_tools

#SEEALSO
experimental_features
