=== Edit in Place ===

In this dialog you can edit one line of the text document.

Click OK or press {key_editinplace} to place the modified text in the document.

You can open the *Edit in Place* dialog by Shift-clicking a clickable object in
the Music View or by right-clicking the object and selecting {menu_editinplace}.

#VARS
key_editinplace text Ctrl+Return
menu_editinplace menu Edit in Place
