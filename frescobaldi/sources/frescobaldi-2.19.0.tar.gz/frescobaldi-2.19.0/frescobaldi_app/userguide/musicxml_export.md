=== Export Music XML ===

Convert LilyPond source to MusicXML (without using LilyPond).

You can use the MusicXML-file to export to other applications.

This feature is currently experimental, see {experimental}.

#SEEALSO
musicxml_import

#VARS
experimental help experimental_features
