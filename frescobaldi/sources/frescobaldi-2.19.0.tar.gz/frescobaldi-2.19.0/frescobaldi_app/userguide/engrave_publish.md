=== Publish mode ===

When engraving a score in Publication mode ({key_engrave_publish}), the 
point-and-click information isn't generated. This will prevent a reader of 
the resulting PDF document from navigating to the corresponding line in the 
input file, but it will also significantly decrease the file size.

You should also note that the point-and-click links contain hard-coded path 
information of your system, which may be considered a security issue.

#VARS
key_engrave_publish shortcut engrave engrave_publish

