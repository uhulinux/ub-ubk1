=== Contributing ===
    
Frescobaldi is a [http://www.gnu.org/philosophy/free-sw.html Free Software]
project to create a user friendly LilyPond music score editor.
The goal is to make Frescobaldi available on all major platforms.

Frescobaldi is developed in a public GitHub repository at {url}.
There you can browse or checkout the source code and report bugs and wishes.

You can contribute by simply using Frescobaldi and reporting bugs and suggestions.
Translations are also very welcome. How to create new translations is described
in the file `README-translations` in the source distribution of Frescobaldi.
If you want to add functionality you can find information about the source code
structure in the file `README-development`.

#VARS
url URL http://github.com/wbsoft/frescobaldi

#SEEALSO
experimental_features
