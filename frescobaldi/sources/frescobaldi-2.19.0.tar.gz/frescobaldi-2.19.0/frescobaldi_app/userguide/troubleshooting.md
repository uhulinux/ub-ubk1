=== Troubleshooting ===

Sometimes things don't go the way you would expect;
this section may give some solutions.
    
#SUBDOCS
nomusic
create_midi
midi_synth
