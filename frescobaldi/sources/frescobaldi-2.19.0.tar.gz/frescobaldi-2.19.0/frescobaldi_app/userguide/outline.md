=== Document Outline ===

The Document Outline (menu {tools}) shows important lines from your document
and enables you to quickly navigate to them.

#SEEALSO
outline_configure


#VARS
tools menu tools

