=== Editing Files ===

In this part the features of the editor are discussed, e.g. how to control 
auto-indenting, how to use search and replace, etcetera.

#SUBDOCS
search_replace
indent_format
pitch
rhythm
lyrics
docvars
snippets

