=== Paths ===
    
Here, directories can be added that contain `hyph_*.dic` files,
where the `*` stands for different language codes.

These hyphenation dictionaries are used by Frescobaldi to break
lyrics text into syllables.
