=== Preview mode ===

This mode ({key_engrave_preview}) runs LilyPond with the `-dpoint-and-click`
commandline option. This enables the clickable notes and other objects in the
PDF.

Using these links, the Music View is able to provide smart two-way navigation
between the Music View and the LilyPond source.

The links also increase the size of the rendered PDF significantly, so when
you want to share the rendered PDF with others, it is better to use the
[engrave_publish publish mode].

#VARS
key_engrave_preview shortcut engrave engrave_preview

