Hyphenation dictionary
----------------------

Language: Czech (Czech Republic) (cs CZ).
Origin:   Based on the TeX hyphenation tables
License:  GPL license, 2003
Author:   Pavel@Janik.cz (Pavel Jan�k)

HYPH cs CZ hyph_cs

 These patterns were converted from TeX hyphenation patterns by the package
 lingucomponent-tools
 (http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/oo-cs/lingucomponent-tools/). 

 The license of original files is GNU GPL (they are both parts of csTeX). My
 work on them was to only run the scripts from lingucomponent-tools package
 (dual LGPL/SISSL license so it can be integrated).
 -- 
 Pavel Jan�k
 2003
 
