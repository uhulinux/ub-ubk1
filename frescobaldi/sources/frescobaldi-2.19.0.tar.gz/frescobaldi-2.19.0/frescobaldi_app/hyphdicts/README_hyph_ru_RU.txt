Hyphenation dictionary
----------------------

Language: Russian (ru RU).  
Origin:   Based on the TeX hyphenation tables 
License:  GNU LGPL license.  
Author:   conversion author is Peter Novodvorsky <nidd@altlinux.ru>

This hyphenation dictionary is based on syllable matching patterns and
should be usable under other variations of Russian

HYPH ru RU hyph_ru_RU
